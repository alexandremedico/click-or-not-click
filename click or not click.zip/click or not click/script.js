// Définit un élément séléctionné
//document.querySelector('#menu')
// Ajoute un event listener sur l'action click
// On éxécute la fonction anonyme
//.addEventListener('click', function() {
  // On selectionne le aside, let = variable,
  // utilisation d'un fonction css dans le js
  // toggle affiche et retire le asideMenu
  //let asideMenu = document.querySelector('aside');
  //asideMenu.classList.toggle('width-hidden')

  // document.querySelector('aside').classList.toggle('width-hidden')

  // let section = document.querySelector('section');
  // section.classList.toggle('menu-open');
  // section.classList.toggle('menu-close');
  // section : fonction dans main
  // menu-open&close : fonction pour le css
//});

document.querySelector('#start')
.addEventListener('click', function() {
  let goodGuy = document.createElement('IMG');
  let maxTop = 58;
  let maxLeft = 30;
  let blurpx = 0;
  goodGuy.src = "./image/giphy.gif";
  goodGuy.classList.add('game-image');
  goodGuy.id = "goodGuy";


  let badGuy = document.createElement('IMG');
  badGuy.src = './image/tete.gif';
  badGuy.classList.add('game-image');
  badGuy.id = 'badGuy';

  document.querySelector('body').appendChild(goodGuy);

  setInterval(function() {
    if(Math.floor((Math.random() * 10) + 1) < 9) {
      let newGuy = goodGuy.cloneNode(true);
      newGuy.style.top = Math.floor((Math.random() * maxTop) + 1) + "vh";
      newGuy.style.left = Math.floor((Math.random() * maxLeft) + 1) + "vw";
      document.querySelector('body').appendChild(newGuy);
    } else {
      badGuy.style.top = Math.floor((Math.random() * maxTop) + 1) + "vh";
      badGuy.style.left = Math.floor((Math.random() * maxLeft) + 1) + "vw";
      document.querySelector('body').appendChild(badGuy);
    }
  }, 1000);


  document.querySelector('body').addEventListener('click', function(clickedElement) {
    let click = clickedElement.target;
    if(click.id == "goodGuy") {
      blurpx = blurpx - 1;
      // incrémentation de -1 quand blur est sup ou égale à 2 et que clique sur goodGuy
      document.querySelector('body').style.filter = 'blur(' + blurpx + 'px)';
      click.remove();
    } else if(click.id == 'badGuy') {
      blurpx = blurpx + 2;
      // incrémentation de +2 quand click sur badGuy
      document.querySelector('body').style.filter = 'blur(' + blurpx + 'px)';
    }
  })
  /*document.querySelector('body').appendChild(goodGuy);
  document.querySelector('#goodGuy')
  .addEventListener('click', function() {
    document.querySelector('#goodGuy').remove();
  })*/
});
